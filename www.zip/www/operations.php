<html>

<head>
  <style>
    body {
      background-image: url(wp.jpg);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .button {
      font-family: 'Source Sans Pro', sans-serif;
      font-weight: 900;
      padding: 1.25rem 2rem;
      font-size: 1rem;
      border-radius: 3.5rem / 100%;
      position: relative;
      min-width: 15rem;
      max-width: 90vw;
      overflow: hidden;
      border: 0;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .button1 {
      background-color: white;
      color: #3d5e81;
    }

    .button1:hover {
      background-color: #3d5e81;
      color: white;
    }

    span {
      position: relative;
      z-index: 1;
    }

    .button span {
      cursor: pointer;
      display: inline-block;
      position: relative;
      transition: 0.5s;
    }

    .button span:after {
      content: '\00bb';
      position: absolute;
      opacity: 0;
      top: 0;
      right: -20px;
      transition: 0.5s;
    }

    .button:hover span {
      padding-right: 25px;
    }

    .button:hover span:after {
      opacity: 1;
      right: 0;
    }

    .fixedbutton {
      position: fixed;
      bottom: 10px;
      right: 10px;
      font-family: 'Source Sans Pro', sans-serif;
      font-weight: 900;
      padding: 1rem 1rem;
      font-size: 0.8rem;
      border-radius: 3.5rem / 100%;
      min-width: 5rem;
      max-width: 90vw;
      overflow: hidden;
      border: 0;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      background-color: white;
      color: #3d5e81;
    }
  </style>
</head>

<body>
  <?php
  session_start();
  ?>
  <center>
    <h1 style=color:white;font-family:Calibri>SELECT AN OPERATION</h1>

    <a href="view.php"><button class="button button1"><span>View</span></button></a>
    <a href="select.php"><button class="button button1"><span>Select</span></button></a>
    <a href="insert.php"><button class="button button1"><span>Insert</span></button></a>
    <a href="update.php"><button class="button button1"><span>Update</span></button></a>
    <a href="delete.php"><button class="button button1"><span>Delete</span></button></a>
    <br><br>
    <a href="inc/logout.php"><button class="button button1 fixedbutton" data-toggle="modal" data-target=".bs-example-modal-sm">Logout From <?php echo $_SESSION["username"]; ?> Level</button></a>
    </div>

  </center>
</body>

</html>