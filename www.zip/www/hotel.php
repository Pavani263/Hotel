-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Oct 06, 2020 at 08:43 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `g24_s02`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `Guest_ID` int(5) NOT NULL,
  `Cost` float NOT NULL,
  PRIMARY KEY (`Guest_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chef_speciality`
--

DROP TABLE IF EXISTS `chef_speciality`;
CREATE TABLE IF NOT EXISTS `chef_speciality` (
  `Emp_ID` int(5) NOT NULL,
  `Speciality` varchar(20) NOT NULL,
  PRIMARY KEY (`Emp_ID`,`Speciality`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clean`
--

DROP TABLE IF EXISTS `clean`;
CREATE TABLE IF NOT EXISTS `clean` (
  `RoomNo` int(5) NOT NULL,
  `Emp_ID` int(5) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  PRIMARY KEY (`RoomNo`,`Emp_ID`),
  KEY `clean_ibfk_1` (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cleaning_staff`
--

DROP TABLE IF EXISTS `cleaning_staff`;
CREATE TABLE IF NOT EXISTS `cleaning_staff` (
  `Emp_ID` int(5) NOT NULL,
  `Location` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `Guest_ID` int(5) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  PRIMARY KEY (`Guest_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `Emp_ID` int(5) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` enum('Male','Female') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Contact_no` varchar(10) NOT NULL,
  `Salary_grade` varchar(20) NOT NULL,
  `Start_date` date NOT NULL,
  `Facility_ID` int(5) DEFAULT NULL,
  PRIMARY KEY (`Emp_ID`),
  KEY `employee_ibfk_1` (`Facility_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Emp_ID`, `Name`, `Gender`, `Contact_no`, `Salary_grade`, `Start_date`, `Facility_ID`) VALUES
(231, 'dfda', '', '24123123', 'asdd', '2020-10-06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `facility`
--

DROP TABLE IF EXISTS `facility`;
CREATE TABLE IF NOT EXISTS `facility` (
  `Facility_ID` int(5) NOT NULL,
  `Rate` float DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Location` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Facility_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
CREATE TABLE IF NOT EXISTS `family` (
  `Guest_ID` int(5) NOT NULL,
  `Familyhead_NIC` varchar(15) NOT NULL,
  `Familyhead_name` varchar(50) NOT NULL,
  `Familyhead_gender` enum('Male','Female') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Guest_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
CREATE TABLE IF NOT EXISTS `food` (
  `Food_ID` int(5) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Rate` float DEFAULT NULL,
  `Portion_amount` enum('Single','Double','Multiple','Group') DEFAULT NULL,
  `Emp_ID` int(5) DEFAULT NULL,
  PRIMARY KEY (`Food_ID`),
  KEY `food_ibfk_1` (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
CREATE TABLE IF NOT EXISTS `guest` (
  `Guest_ID` int(5) NOT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Check_in_date` date NOT NULL,
  `Check_out_date` date NOT NULL,
  `Emp_ID` int(5) DEFAULT NULL,
  PRIMARY KEY (`Guest_ID`),
  KEY `Emp_ID` (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `guest_contact`
--

DROP TABLE IF EXISTS `guest_contact`;
CREATE TABLE IF NOT EXISTS `guest_contact` (
  `Guest_ID` int(5) NOT NULL,
  `Contact_no` int(5) NOT NULL,
  PRIMARY KEY (`Guest_ID`,`Contact_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `handle`
--

DROP TABLE IF EXISTS `handle`;
CREATE TABLE IF NOT EXISTS `handle` (
  `Guest_ID` int(5) NOT NULL,
  `Emp_ID` int(5) NOT NULL,
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL,
  PRIMARY KEY (`Guest_ID`,`Emp_ID`),
  KEY `Emp_ID` (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `individual`
--

DROP TABLE IF EXISTS `individual`;
CREATE TABLE IF NOT EXISTS `individual` (
  `Guest_ID` int(5) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` enum('Male','Female') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Guest_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `indoor`
--

DROP TABLE IF EXISTS `indoor`;
CREATE TABLE IF NOT EXISTS `indoor` (
  `Facility_ID` int(5) NOT NULL,
  `Resevation_requirment` varchar(50) NOT NULL,
  PRIMARY KEY (`Facility_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kitchen`
--

DROP TABLE IF EXISTS `kitchen`;
CREATE TABLE IF NOT EXISTS `kitchen` (
  `Emp_ID` int(5) NOT NULL,
  `Grade` varchar(20) NOT NULL,
  `Experience` int(5) DEFAULT NULL,
  `contract_period` int(2) NOT NULL,
  `Chef_flag` tinyint(1) NOT NULL,
  `Support_staff_flag` tinyint(1) NOT NULL,
  `waiter_flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

DROP TABLE IF EXISTS `management`;
CREATE TABLE IF NOT EXISTS `management` (
  `Emp_ID` int(5) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `Grade` varchar(10) NOT NULL,
  PRIMARY KEY (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_food`
--

DROP TABLE IF EXISTS `order_food`;
CREATE TABLE IF NOT EXISTS `order_food` (
  `Guest_ID` int(5) NOT NULL,
  `Food_ID` int(5) NOT NULL,
  PRIMARY KEY (`Guest_ID`,`Food_ID`),
  KEY `Food_ID` (`Food_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outdoor`
--

DROP TABLE IF EXISTS `outdoor`;
CREATE TABLE IF NOT EXISTS `outdoor` (
  `Facility_ID` int(5) NOT NULL,
  `Guiding_requirment` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Special_requirment` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`Facility_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

DROP TABLE IF EXISTS `receptionist`;
CREATE TABLE IF NOT EXISTS `receptionist` (
  `Emp_ID` int(5) NOT NULL,
  PRIMARY KEY (`Emp_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `RoomNo` int(5) NOT NULL,
  `Room_type` varchar(50) DEFAULT NULL,
  `Rate` float DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `Location` varchar(50) DEFAULT NULL,
  `Guest_ID` int(5) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`),
  KEY `Guest_ID` (`Guest_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `use_facility`
--

DROP TABLE IF EXISTS `use_facility`;
CREATE TABLE IF NOT EXISTS `use_facility` (
  `Guest_ID` int(5) NOT NULL,
  `Facility_ID` int(5) NOT NULL,
  `Duration` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Guest_ID`,`Facility_ID`),
  KEY `Facility_ID` (`Facility_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `waiter_speciality_style`
--

DROP TABLE IF EXISTS `waiter_speciality_style`;
CREATE TABLE IF NOT EXISTS `waiter_speciality_style` (
  `Emp_ID` int(5) NOT NULL,
  `Speciality_style` varchar(20) NOT NULL,
  PRIMARY KEY (`Emp_ID`,`Speciality_style`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `chef_speciality`
--
ALTER TABLE `chef_speciality`
  ADD CONSTRAINT `chef_speciality_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `clean`
--
ALTER TABLE `clean`
  ADD CONSTRAINT `clean_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `clean_ibfk_2` FOREIGN KEY (`RoomNo`) REFERENCES `room` (`RoomNo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cleaning_staff`
--
ALTER TABLE `cleaning_staff`
  ADD CONSTRAINT `cleaning_staff_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `company_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Facility_ID`) REFERENCES `facility` (`Facility_ID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `family`
--
ALTER TABLE `family`
  ADD CONSTRAINT `family_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `food_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `guest`
--
ALTER TABLE `guest`
  ADD CONSTRAINT `guest_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `guest_contact`
--
ALTER TABLE `guest_contact`
  ADD CONSTRAINT `guest_contact_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `handle`
--
ALTER TABLE `handle`
  ADD CONSTRAINT `handle_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `handle_ibfk_2` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `individual`
--
ALTER TABLE `individual`
  ADD CONSTRAINT `individual_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `indoor`
--
ALTER TABLE `indoor`
  ADD CONSTRAINT `indoor_ibfk_1` FOREIGN KEY (`Facility_ID`) REFERENCES `facility` (`Facility_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kitchen`
--
ALTER TABLE `kitchen`
  ADD CONSTRAINT `kitchen_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `management`
--
ALTER TABLE `management`
  ADD CONSTRAINT `management_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_food`
--
ALTER TABLE `order_food`
  ADD CONSTRAINT `order_food_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_food_ibfk_2` FOREIGN KEY (`Food_ID`) REFERENCES `food` (`Food_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `outdoor`
--
ALTER TABLE `outdoor`
  ADD CONSTRAINT `outdoor_ibfk_1` FOREIGN KEY (`Facility_ID`) REFERENCES `facility` (`Facility_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD CONSTRAINT `receptionist_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `use_facility`
--
ALTER TABLE `use_facility`
  ADD CONSTRAINT `use_facility_ibfk_1` FOREIGN KEY (`Facility_ID`) REFERENCES `facility` (`Facility_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `use_facility_ibfk_2` FOREIGN KEY (`Guest_ID`) REFERENCES `guest` (`Guest_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `waiter_speciality_style`
--
ALTER TABLE `waiter_speciality_style`
  ADD CONSTRAINT `waiter_speciality_style_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
