<?php

class Hello extends Controller{

    function _Construct(){
        parent::_construct();
    }

    function index(){
        $this->view->render('hello/index');
    }
?>