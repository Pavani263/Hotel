<?php
session_start();
?>
<html>

<head>

  <style>
    body {
      background-image: url(wp.jpg);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .box {
      display: none;
    }

    .Food {
      background: #ff0000;
    }

    .Room {
      background: #228B22;
    }

    .button {
      font-family: 'Source Sans Pro', sans-serif;
      font-weight: 900;
      padding: 1.25rem 2rem;
      font-size: 1rem;
      border-radius: 3.5rem / 100%;
      position: relative;
      min-width: 15rem;
      max-width: 90vw;
      overflow: hidden;
      border: 0;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .button1 {
      background-color: white;
      color: #3d5e81;
    }

    .button1:hover {
      background-color: #3d5e81;
      color: white;
    }

    span {
      position: relative;
      z-index: 1;
    }

    .button span {
      cursor: pointer;
      display: inline-block;
      position: relative;
      transition: 0.5s;
    }

    .button span:after {
      content: '\00bb';
      position: absolute;
      opacity: 0;
      top: 0;
      right: -20px;
      transition: 0.5s;
    }

    .button:hover span {
      padding-right: 25px;
    }

    .button:hover span:after {
      opacity: 1;
      right: 0;
    }


    .form-style-5 {
      max-width: 500px;
      padding: 10px 20px;
      background: white;
      margin: 10px auto;
      padding: 20px;
      background: white;
      border-radius: 8px;
      font-family: 'Source Sans Pro', sans-serif;
    }

    .form-style-5 fieldset {
      border: none;
    }

    .form-style-5 legend {
      font-size: 1.4em;
      margin-bottom: 10px;
    }

    .form-style-5 label {
      display: block;
      margin-bottom: 8px;
    }

    .form-style-5 input[type="text"],
    .form-style-5 input[type="date"],
    .form-style-5 input[type="datetime"],
    .form-style-5 input[type="email"],
    .form-style-5 input[type="number"],
    .form-style-5 input[type="search"],
    .form-style-5 input[type="time"],
    .form-style-5 input[type="url"],
    .form-style-5 textarea,
    .form-style-5 select {
      font-family: 'Source Sans Pro', sans-serif;
      background: rgba(255, 255, 255, .1);
      border: none;
      border-radius: 4px;
      font-size: 15px;
      margin: 0;
      outline: 0;
      padding: 10px;
      width: 100%;
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      background-color: #e6e6e6;
      color: #3d5e81;
      -webkit-box-shadow: 0 1px 0 rgba(0, 0, 0, 0.03) inset;
      box-shadow: 0 1px 0 rgba(0, 0, 0, 0.03) inset;
      margin-bottom: 30px;
    }

    .form-style-5 input[type="text"]:focus,
    .form-style-5 input[type="date"]:focus,
    .form-style-5 input[type="datetime"]:focus,
    .form-style-5 input[type="email"]:focus,
    .form-style-5 input[type="number"]:focus,
    .form-style-5 input[type="search"]:focus,
    .form-style-5 input[type="time"]:focus,
    .form-style-5 input[type="url"]:focus,
    .form-style-5 textarea:focus,
    .form-style-5 select:focus {
      background: white;
    }

    .form-style-5 select {
      -webkit-appearance: menulist-button;
      height: 35px;
    }

    .form-style-5 .number {
      background: #1abc9c;
      color: #fff;
      height: 30px;
      width: 30px;
      display: inline-block;
      font-size: 0.8em;
      margin-right: 4px;
      line-height: 30px;
      text-align: center;
      text-shadow: 0 1px 0 rgba(255, 255, 255, 0.2);
      border-radius: 15px 15px 15px 0px;
    }

    .fixedbutton {
      position: fixed;
      bottom: 10px;
      right: 10px;
      font-family: 'Source Sans Pro', sans-serif;
      font-weight: 900;
      padding: 1rem 1rem;
      font-size: 0.8rem;
      border-radius: 3.5rem / 100%;
      min-width: 5rem;
      max-width: 90vw;
      overflow: hidden;
      border: 0;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      background-color: white;
      color: #3d5e81;
    }
  </style>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script>
    $(document).ready(function() {
      $("select").change(function() {
        $(this).find("option:selected").each(function() {
          var optionValue = $(this).attr("value");
          if (optionValue) {
            $(".box").not("." + optionValue).hide();
            $("." + optionValue).show();
          } else {
            $(".box").hide();
          }
        });
      }).change();
    });
  </script>

</head>

<body>
  <center>

    <h1 style=color:white;font-family:Calibri>SELECT AN OPERATION</h1>

    <a href="view.php"><button class="button button1"><span>View</span></button></a>
    <a href="select.php"><button class="button button1"><span>Select</span></button></a>
    <a href="insert.php"><button class="button button1"><span>Insert</span></button></a>
    <a href="update.php"><button class="button button1"><span>Update</span></button></a>
    <a href="delete.php"><button class="button button1"><span>Delete</span></button></a>

    <div class="form-style-5">

      <form method="post" action="inc/delete_element.php">
        <fieldset>
          <div>
            <legend>
              <font color="#3d5e81" style="font-family: 'Source Sans Pro', sans-serif;font-weight: 900; text-transform: uppercase;letter-spacing: 0.05em;font-size: 1rem;">Delete
            </legend>
            <select name="tName">
              <option value="" selected="selected">Select Table</option>
              <option value="Food">Food</option>
              <option value="Employee">Employee</option>
            </select>
          </div>
          <div class="Employee box form-style-5">
            <input type="text" name="EmpID" placeholder="Employee No" id="EmployeeData">
          </div>

          <div class="Food box form-style-5">
            <input type="text" name="FoodID" placeholder="Food ID" id="FoodData">
          </div>

        </fieldset>

        <input type="submit" value="Delete" class="button button1" />
      </form>
      <br><br>

    </div>
    <a href="inc/logout.php"><button class="button button1 fixedbutton" data-toggle="modal" data-target=".bs-example-modal-sm">Logout From <?php echo $_SESSION["username"]; ?> Level</button></a>
  </center>
</body>

</html>