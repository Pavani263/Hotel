<!DOCTYPE html>
<html>
<head>
    <title>MVC_UI</title>
</head>
<body>
<script>
function doSearch () {
    var data = new FormData();
    data.append("search", document.getElementById("search").value);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "../controller/controller.php");
    xhr.onload = function(){
        let results = document.getElementById("results"),
        search = JSON.parse(this.response);
        results.innerHTML = "";
        if (search !== null) { for (let s of search){
            results.innerHTML += `<div>${s.id} - ${s.name}</div>`;
        }}
    };
    xhr.send(data);
    return false;
}
</script>

<form onsubmit="return doSearch()">
  <input type="text" id= "search" required/>
  <input type="submit" value="Search"/>
</form>
 
Result
<div id="results"></div>

   </body>
</html>