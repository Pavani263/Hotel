<?php
phpinfo();
$no=25;
echo "This is $no";
?>