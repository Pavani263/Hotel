<?php
require "../model/model.php";
$DB = new DB();
$pw=md5($_POST['pw']);
$DB->insert_data(
   "INSERT INTO `userdetails` (`id`, `firstname`, `lastname`, `password`) VALUES ('".$_POST['id']."','".$_POST['fname']."','".$_POST['lname']."','$pw')"); 
?>