<?php
require "../model/model.php";
$DB = new DB();

$results = $DB->select_data(
  "SELECT * FROM `userdetails` WHERE `firstname` LIKE ? OR `lastname` LIKE ? order by `id`",["%{$_POST['search']}%","%{$_POST['search']}%"]);

echo json_encode(count($results)==0 ? null : $results);

?>

