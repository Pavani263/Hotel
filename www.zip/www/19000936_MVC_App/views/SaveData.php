
<html>
    <head> 
        <title>MVC_UI_Application</title> 
    </head> 
<body> 
<script>
</script>
    <table>
    <form action="../controller/Insert.php" method="POST">
    <tr>
    <td>ID</td>
    <td><input type="text" id="id" name="id" /></td>
    </tr>
    <tr>
    <td>First Name</td>
    <td><input type="text" id="fname" name="fname" /></td>
    <tr>
    <td>Last Name</td>
    <td><input type="text" id="lname" name="lname"/></td>
    <tr>
    <td>Password</td>
    <td><input type="password" id="pw" name="pw"/></tr>
    </table>
    <tr>
    <button type="submit" value="submit">Submit</button></tr>
    </form>
    </br></br>
    <Button><a href="ViewData.php">Show</a></Button>


</body> 
</html> 
