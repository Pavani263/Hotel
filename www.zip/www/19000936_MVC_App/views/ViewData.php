<html>
    <head> 
        <title>MVC_UI_Application</title>   
    </head> 
    <body> 

<script>
function doSearch () {

  var data = new FormData();
  data.append("search", document.getElementById("search").value);

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "../controller/Show.php");
  xhr.onload = function(){
    let results = document.getElementById("results"),
    search = JSON.parse(this.response);
    results.innerHTML = "";
    if (search !== null) { for (let s of search) {
      results.innerHTML += `<div>${s.id} - ${s.firstname} ${s.lastname}</div>`;
    }}
  };
  xhr.send(data);
  return false;
}
</script>

<form onsubmit="return doSearch()">
  <input type="text" id="search" required/>
  <input type="submit" />
</form> 

<h3>Results...</h3>
<div id="results"></div></br>

<Button><a href="SaveData.php">Insert</a></Button>
    </body> 
</html> 
