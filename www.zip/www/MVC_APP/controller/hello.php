<?php
class Controller {
    public function __construct() {
    }
  }
class Hello extends Controller{
    function __construct() { 
        parent::__construct(); 
    } 
    function index(){
        $this->view->render('hello/index');
    }
}
?>