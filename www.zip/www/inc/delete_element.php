<?php
include 'connection.php';
error_reporting(0);
session_start();

//echo "sjhdajhdsaaaaaaaaaadssssssssss";



$tName = $_POST['tName'];
$EmpID = $_POST['EmpID'];
$FoodID = $_POST['FoodID'];


$con = connect($_SESSION['username'], $_SESSION['password']);
if ($tName == "Food") {
    $sql = "DELETE FROM `food` WHERE Food_ID = $FoodID;";
} elseif ($tName == "Employee") {
    $sql = "DELETE FROM `employee` WHERE Emp_ID = $EmpID;";
} else {
    echo ("<script LANGUAGE='JavaScript'>
            window.alert('Please enter details.');
            window.location.href='../delete.php';
        </script>");
}


if (mysqli_query($con, $sql)) {
    echo ("<script LANGUAGE='JavaScript'>
            window.alert('Deleted record successfully');
            window.location.href='../operations.php';
        </script>");
} else {
    $error = mysqli_error($con);
    echo '<script type="text/javascript">window.alert("' . $error . '");
    window.location.href="../delete.php";
    </script>';
}
mysqli_close($con);
