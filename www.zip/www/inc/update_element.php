<?php
include 'connection.php';
//error_reporting(0);
session_start();

//echo "sjhdajhdsaaaaaaaaaadssssssssss";



$utable = $_POST['utable'];

$RoomNo = $_POST['RoomNo'];
$RateR = $_POST['RateR'];

$FoodID = $_POST['FoodID'];
$RateF = $_POST['RateF'];

$con = connect($_SESSION['username'], $_SESSION['password']);
if ($utable == "Food") {
    $sql = "UPDATE `food` SET `Rate`=$RateF WHERE Food_ID = $FoodID;";
} elseif ($utable == "Room") {
    $sql = "UPDATE `room` SET `Rate`=$RateR WHERE RoomNo = $RoomNo;";
} else {
    echo ("<script LANGUAGE='JavaScript'>
            window.alert('Please enter details.');
            window.location.href='../update.php';
        </script>");
}


if (mysqli_query($con, $sql)) {
    echo ("<script LANGUAGE='JavaScript'>
            window.alert('Updated record successfully');
            window.location.href='../operations.php';
        </script>");
} else {
    $error = mysqli_error($con);
    echo '<script type="text/javascript">window.alert("' . $error . '");
    window.location.href="../update.php";
    </script>';
}
mysqli_close($con);
