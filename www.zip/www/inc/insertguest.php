<?php
include 'connection.php';
error_reporting(0);
session_start();

//echo "sjhdajhdsaaaaaaaaaadssssssssss";



$GuestID = $_POST['GuestID'];
$Type = $_POST['category'];
$CheckIn = $_POST['CheckIn'];
$CheckOut = $_POST['CheckOut'];
$EmpID = $_POST['EmpID'];

$category = $_POST['category'];

$fhnic = $_POST['fhnic'];
$fhname = $_POST['fhname'];
$fhgender = $_POST['fhgender'];

$inic = $_POST['inic'];
$iname = $_POST['iname'];
$igender = $_POST['igender'];

$cname = $_POST['cname'];
$caddress = $_POST['caddress'];

$Contact_no = $_POST['Contact_no'];

$con = connect($_SESSION['username'], $_SESSION['password']);
if ($EmpID == "") {
    $sql = "INSERT INTO `guest` (`Guest_ID`, `Guest_Type`, `Check_in_date`, `Check_out_date`, `Emp_ID`) VALUES ($GuestID, '$Type', '$CheckIn', '$CheckOut', NULL);";
} else {
    $sql = "INSERT INTO `guest` (`Guest_ID`, `Guest_Type`, `Check_in_date`, `Check_out_date`, `Emp_ID`) VALUES ($GuestID, '$Type', '$CheckIn', '$CheckOut', $EmpID);";
}

$sqlcn = "INSERT INTO `guest_contact`(`Guest_ID`, `Contact_no`) VALUES ($GuestID,'$Contact_no');";

$sqlf = "INSERT INTO `family` (`Guest_ID`, `Familyhead_NIC`, `Familyhead_name`, `Familyhead_gender`) VALUES ($GuestID,'$fhnic', '$fhname', '$fhgender');";
$sqli = "INSERT INTO `individual` (`Guest_ID`, `NIC`, `Individual_Name`, `Gender`) VALUES ($GuestID,'$inic','$iname','$igender');";
$sqlc = "INSERT INTO `company` (`Guest_ID`, `Company_Name`, `Address`) VALUES ($GuestID,'$cname','$cname');";

if ($category == "Individual") {
    if (mysqli_query($con, $sql) && mysqli_query($con, $sqli) && mysqli_query($con, $sqlcn)) {
        echo ("<script LANGUAGE='JavaScript'>
            window.alert('Records added successfully');
            window.location.href='../operations.php';
        </script>");
    } else {
        $error = mysqli_error($con);
        echo '<script type="text/javascript">window.alert("' . $error . '");
    window.location.href="../insert.php";
    </script>';
    }
    //mysqli_query($con, $sqli);
} elseif ($category == "Family") {
    if (mysqli_query($con, $sql) && mysqli_query($con, $sqlf) && mysqli_query($con, $sqlcn)) {
        echo ("<script LANGUAGE='JavaScript'>
            window.alert('Records added successfully');
            window.location.href='../operations.php';
        </script>");
    } else {
        $error = mysqli_error($con);
        echo '<script type="text/javascript">window.alert("' . $error . '");
    window.location.href="../insert.php";
    </script>';
    }
    //mysqli_query($con, $sqlf);
} elseif ($category == "Company") {
    if (mysqli_query($con, $sql) && mysqli_query($con, $sqlc) && mysqli_query($con, $sqlcn)) {
        echo ("<script LANGUAGE='JavaScript'>
            window.alert('Records added successfully');
            window.location.href='../operations.php';
        </script>");
    } else {
        $error = mysqli_error($con);
        echo '<script type="text/javascript">window.alert("' . $error . '");
    window.location.href="../insert.php";
    </script>';
    }
    //mysqli_query($con, $sqlc);
} else {
    echo ("<script LANGUAGE='JavaScript'>
            window.alert('Please enter category details.');
            window.location.href='../insert.php';
        </script>");
}


mysqli_close($con);
