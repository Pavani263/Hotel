<?php
//session_start();
error_reporting(0);

function connect($username, $password)
{

  $dbservername = "localhost:3308";
  $dbusername = $username;
  $dbpassword = $password;
  $dbname = "g24_s02";

  $con = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
  if (!$con) {
    if (mysqli_connect_errno()) {
      echo "<script type='text/javascript'>alert('Username password does not match');</script>";
    }
    die; //("Connection failed: " . mysqli_connect_error());
  }
  //echo "Connected successfully";
  $_SESSION["username"] = $username;
  $_SESSION["password"] = $password;
  //print_r($_SESSION);
  //header("Location:../operations.php");
  return $con;
}
